{
	"name" : [
		"Sean Connery",
		"Brit Ekland",
		"Roger Moore"
	],
	"sex" : [
		"male",
		"female",
		"male"
	],
	"age" : [
		32,
		28,
		null
	]
}
