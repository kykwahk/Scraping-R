
## books.html

html.string <- c(
  '<!DOCTYPE html>',
  '<html>',
  '<head>',
  '<title>Recommended Books</title>',
  '</head>',
  '<body>',
  '<h1>Books for Seaside Reading</h1>',
  '<p>Reading List</p>',
  '<table>',
  '<tr> <th>Title</th> <th>Author</th> <th>Publisher</th> </tr>',
  '<tr> <td>The Old Man and The Sea</td> <td>Ernest Hemingway</td> <td>Scribner</td> </tr>',
  '<tr> <td>Moby Dick</td> <td>Herman Melville</td> <td>Simon and Brown</td> </tr>',
  '</table>',
  '<br>',
  '<a href="http://www.amazon.com">Click Here to Buy</a>',
  '</body>',
  '</html>'
)
writeLines(html.string, "books.html")

library(pander)
openFileInOS("books.html")

## books.xml

xml.string <- c(
  '<?xml version="1.0" encoding="UTF-8"?>',
  '<books>',
  '<book lang="eng" format="paperback" pages="128">',
  '<title>The Old Man and The Sea</title>',
  '<author>',
  '<first_name>Ernest</first_name>',
  '<last_name>Hemingway</last_name>',
  '</author>',
  '<year>1995</year>',
  '<publisher>Scribner</publisher>',
  '</book>',
  '<book lang="eng" format="hardcover" pages="488">',
  '<title>Moby Dick</title>',
  '<author>',
  '<first_name>Herman</first_name>',
  '<last_name>Melville</last_name>',
  '</author>',
  '<year>2016</year>',
  '<publisher>Simon and Brown</publisher>',
  '</book>',
  '</books>'
)
writeLines(xml.string, "books.xml")

library(pander)
openFileInOS("books.xml")

## bookinside.xml

xml.string2 <- c(
  '<?xml version="1.0" encoding="UTF-8"?>',
  '<!DOCTYPE html>',
  '<root xmlns:t="http://www.html.com/myhtml" xmlns:m="http://www.xml.com/myxml">',
  '<t:head>',
  '<t:title>Look Inside!</t:title>',
  '</t:head>',
  '<m:book id="1">',
  '<m:title>Moby Dick</m:title>',
  '<m:author>Herman Melville</m:author>',
  '</m:book>',
  '</root>'
)
writeLines(xml.string2, "bookinside.xml")

library(pander)
openFileInOS("bookinside.xml")

## moviequotes.html

html.string2 <- c(
  '<!DOCTYPE html>',
  '<html>',
  '<head>',
  '<title>Movie Quotes</title>',
  '</head>',
  '<body>',
  '<h1>Famous Quotes from Movies</h1>',
  '<div time="1h 39min" genre="drama" lang="english" date="December/16/1970">',
  '<h2>Ali MacGraw as Jennifer Cavilleri</h2>',
  '<p><i>Love means never having to say you\'re sorry.</i></p>',
  '<p><b>Movie: </b>Love Story</p>',
  '</div>',
  '<div time="2h 22min"  genre="comedy" date="June/23/1994">',
  '<h2>Tom Hanks as Forrest Gump</h2>',
  "<p><i>My mama always said, 'Life was like a box of chocolates; you never know what you\'re gonna get.'</i></p>",
  "<p><i>Mama says,'Stupid is as stupid does.'</i></p>",
  '<p><b>Movie: </b><a href="http://www.imdb.com/title/tt0109830/?ref_=nv_sr_1">Forrest Gump</a></p>',
  '</div>',
  '<p>',
  '<b>Sources:</b><br>',
  '<a href="http://www.afi.com/"><i>American Film Institute</i></a><br>',
  '<a href="http://www.hollywoodreporter.com/"><i>Hollywood Reporters</i></a>',
  '</p>',
  '</body>',
  '</html>'
)
writeLines(html.string2, "moviequotes.html")

library(pander)
openFileInOS("moviequotes.html")
